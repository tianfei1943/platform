package com.smf.platform.log;

/**
 *
 *	
 */
public interface LogOwnerProvider {

	public String getUsername();
	
	public String getRemoteAddress();
}
