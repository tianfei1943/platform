package com.smf.platform.util;

/**
 *
 */
public class PFMailUtils {
	public static void sendMail(String serverIp,String subject,String mail,String password){
		//FIXME 以后实现
	}
}
