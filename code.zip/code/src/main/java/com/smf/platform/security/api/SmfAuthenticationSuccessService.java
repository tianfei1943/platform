package com.smf.platform.security.api;

import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

public interface SmfAuthenticationSuccessService extends
		AuthenticationSuccessHandler {

}
