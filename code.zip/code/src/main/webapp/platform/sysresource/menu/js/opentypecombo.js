$(function(){
$('#openTypeCombo').combobox({   
    url:'platform/sysresource/menu/js/opentypecombo.json',   
    valueField:'id',   
    textField:'text'  
  });
 
});